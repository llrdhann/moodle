<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'assignfeedback_file', language 'id', version '5.2'.
 *
 * @package     assignfeedback_file
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['batchoperationconfirmuploadfiles'] = 'Unggah satu atau lebih berkas umpan balik untuk semua pengguna yang dipilih?';
$string['batchoperationuploadfiles'] = 'Unggah masukan';
$string['batchuploadfiles'] = 'Unggah berkas umpan balik untuk banyak pengguna';
$string['batchuploadfilesforusers'] = 'Kirim berkas umpan bali ke {$a} pengguna terpilih.';
$string['configmaxbytes'] = 'Ukuran berkas maksimum.';
$string['confirmuploadzip'] = 'Konfirmasikan unggahan zip';
$string['countfiles'] = '{$a} berkas';
$string['default'] = 'Diaktifkan sesuai setelan bawaan';
$string['default_help'] = 'Jika disetel, metode umpan balik ini akan diaktifkan secara bawaan untuk semua penugasan baru.';
$string['enabled'] = 'Berkas umpan balik';
$string['enabled_help'] = 'Jika diaktifkan, pengajar akan dapat mengunggah berkas dengan masukan saat menandai pengiriman tugas. Berkas ini mungkin, tetapi tidak terbatas pada, ajuan siswa yang ditandai, dokumen dengan komentar atau umpan balik audio lisan.';
$string['eventfeedback_downloaded'] = 'Berkas umpan balik telah diunduh';
$string['feedbackfileadded'] = 'Berkas umpan balik  "{$a->filename}" untuk siswa "{$a->student}"';
$string['feedbackfileupdated'] = 'Berkas umpan balik yang dimodifikasi  "{$a->filename}" untuk siswa "{$a->student}"';
$string['feedbackzip'] = 'Berkas zip dengan berkas umpan balik';
$string['feedbackzip_help'] = 'Berkas zip yang berisi daftar berkas umpan balik untuk satu atau lebih siswa. Berkas umpan balik akan diberikan kepada siswa berdasarkan ID pengguna yang harus menjadi bagian kedua dari setiap nama berkas segera setelah nama lengkap pengguna. Konvensi penamaan ini digunakan saat mengunduh ajuan sehingga Anda dapat mengunduh semua ajuan, menambahkan komentar ke beberapa berkas, lalu meng-zip ulang dan mengunggah semua berkas. Berkas tanpa perubahan akan diabaikan.';
$string['file'] = 'Berkas umpan balik';
$string['filesadded'] = 'Berkas umpan balik ditambahkan: {$a}';
$string['filesupdated'] = 'Berkas umpan balik diperbarui: {$a}';
$string['importfeedbackfiles'] = 'Impor berkas umpan balik';
$string['maxbytes'] = 'Ukuran berkas maksimum';
$string['maxfiles'] = 'Jumlah maksimum berkas yang diunggah';
$string['maximumsize'] = 'Ukuran berkas maksimum';
$string['moreusers'] = '{$a} lagi...';
$string['nochanges'] = 'Tak ada perubahan';
$string['pluginname'] = 'Berkas umpan balik';
$string['privacy:metadata:filepurpose'] = 'Berkas umpan balik dari pengajar untuk siswa.';
$string['privacy:path'] = 'Berkas umpan balik';
$string['selectedusers'] = 'Pengguna terpilih';
$string['uploadfiles'] = 'Kirim berkas umpan balik';
$string['uploadzip'] = 'Unggah berkas tanggapan dalam bentuk zip';
$string['uploadzipsummary'] = 'Berkas umpan balik yang diimpor dari zip';
$string['userswithnewfeedback'] = 'Pengguna dengan umpan balik yang diperbarui: {$a}';
