<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'aiprovider_awsbedrock', language 'id', version '5.2'.
 *
 * @package     aiprovider_awsbedrock
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action:explain_text:model'] = 'Model AI';
$string['action:explain_text:model_help'] = 'Model yang digunakan untuk menjelaskan teks yang disediakan.';
$string['action:explain_text:systeminstruction'] = 'Instruksi sistem';
$string['action:explain_text:systeminstruction_help'] = 'Instruksi ini dikirimkan ke model AI bersama dengan perintah pengguna. Menyunting instruksi ini tidak disarankan kecuali benar-benar diperlukan.';
$string['action:generate_image:model'] = 'Model AI';
$string['action:generate_image:model_help'] = 'Model yang digunakan untuk menghasilkan gambar dari perintah pengguna. <a href="https://docs.aws.amazon.com/bedrock/latest/userguide/models-supported.html" target="_blank">Model dasar yang didukung di Amazon Bedrock</a>';
$string['action:generate_text:model'] = 'Model AI';
$string['action:generate_text:model_help'] = 'Model yang digunakan untuk menghasilkan respons teks. <a href="https://docs.aws.amazon.com/bedrock/latest/userguide/models-supported.html" target="_blank">Model dasar yang didukung di Amazon Bedrock</a>';
$string['action:generate_text:systeminstruction'] = 'Instruksi sistem';
$string['action:generate_text:systeminstruction_help'] = 'Instruksi ini dikirimkan ke model AI bersama dengan perintah pengguna. Menyunting instruksi ini tidak disarankan kecuali benar-benar diperlukan.';
$string['action:summarise_text:model'] = 'Model AI';
$string['action:summarise_text:model_help'] = 'Model yang digunakan untuk meringkas teks yang disediakan.';
$string['action:summarise_text:systeminstruction'] = 'Instruksi sistem';
$string['action:summarise_text:systeminstruction_help'] = 'Instruksi ini dikirimkan ke model AI bersama dengan perintah pengguna. Menyunting instruksi ini tidak disarankan kecuali benar-benar diperlukan.';
$string['apikey'] = 'Kredensial kunci API Amazon';
$string['apikey_help'] = 'Hasilkan kunci menggunakan Identity and Access Management (IAM) di konsol Amazon Web Services (AWS) atau gunakan  Antarmuka Baris Perintah (CLI) AWS.';
$string['apisecret'] = 'Kredensial rahasia API Amazon';
$string['apisecret_help'] = 'Hasilkan rahasia menggunakan Identity and Access Management (IAM) di konsol Amazon Web Services (AWS) atau gunakan  Antarmuka Baris Perintah (CLI) AWS.';
$string['awsregion'] = 'Wilayah';
$string['awsregion:af-south-1'] = 'Afrika (Cape Town)';
$string['awsregion:ap-east-2'] = 'Asia Pasifik (Taipei)';
$string['awsregion:ap-northeast-1'] = 'Asia Pasifik (Tokyo)';
$string['awsregion:ap-northeast-2'] = 'Asia Pasifik (Seoul)';
$string['awsregion:ap-northeast-3'] = 'Asia Pasifik (Osaka)';
$string['awsregion:ap-south-1'] = 'Asia Pasifik (Mumbai)';
$string['awsregion:ap-south-2'] = 'Asia Pasifik (Hyderabad)';
$string['awsregion:ap-southeast-1'] = 'Asia Pasifik (Singapura)';
$string['awsregion:ap-southeast-2'] = 'Asia Pasifik (Sydney)';
$string['awsregion:ap-southeast-3'] = 'Asia Pasifik (Jakarta)';
$string['awsregion:ap-southeast-4'] = 'Asia Pasifik (Melbourne)';
$string['awsregion:ap-southeast-5'] = 'Asia Pasifik (Malaysia)';
$string['awsregion:ap-southeast-6'] = 'Asia Pasifik (Selandia Baru)';
$string['awsregion:ap-southeast-7'] = 'Asia Pasifik (Thailand)';
$string['awsregion:ca-central-1'] = 'Kanada (Pusat)';
$string['awsregion:ca-west-1'] = 'Kanada Barat (Calgary)';
$string['awsregion:eu-central-1'] = 'Eropa (Frankfurt)';
$string['awsregion:eu-central-2'] = 'Eropa (Zurich)';
$string['awsregion:eu-north-1'] = 'Eropa (Stockholm)';
$string['awsregion:eu-south-1'] = 'Eropa (Milan)';
$string['awsregion:eu-south-2'] = 'Eropa (Spanyol)';
$string['awsregion:eu-west-1'] = 'Eropa (Irlandia)';
$string['awsregion:eu-west-2'] = 'Eropa (London)';
$string['awsregion:eu-west-3'] = 'Eropa (Paris)';
$string['awsregion:il-central-1'] = 'Israel (Tel Aviv)';
$string['awsregion:me-central-1'] = 'Timur Tengah (UEA)';
$string['awsregion:me-south-1'] = 'TImur Tengah (Bahrain)';
$string['awsregion:mx-central-1'] = 'Meksiko (Pusat)';
$string['awsregion:sa-east-1'] = 'Amerika Selatan (São Paulo)';
$string['awsregion:us-east-1'] = 'AS Timur (N. Virginia)';
$string['awsregion:us-east-2'] = 'AS Timur (Ohio)';
$string['awsregion:us-gov-east-1'] = 'AWS GovCloud (US-East)';
$string['awsregion:us-gov-west-1'] = 'AWS GovCloud (US-West)';
$string['awsregion:us-west-1'] = 'AS Barat (N. California)';
$string['awsregion:us-west-2'] = 'AS Barat (Oregon)';
$string['awsregion_help'] = 'Wilayah Amazon Web Services (AWS) di mana model AI dihosting.';
$string['custom_model_name'] = 'Nama model kustom';
$string['extraparams'] = 'Parameter ekstra';
$string['extraparams_help'] = 'Parameter tambahan dapat dikonfigurasikan di sini. Kami mendukung format JSON. Contoh:
<pre>
{
    "temperature": 0.5,
    "max_tokens": 100
}
</pre>';
$string['invalidjson'] = 'String JSON tidak valid';
$string['model_ai21.jamba-1-5-large-v1:0'] = 'AI21 Labs Jamba 1.5 Large';
$string['model_ai21.jamba-1-5-mini-v1:0'] = 'AI21 Labs Jamba 1.5 Mini';
$string['model_amazon.nova-canvas-v1:0'] = 'Amazon Nova Canvas';
$string['model_amazon.nova-lite-v1:0'] = 'Amazon Nova Lite';
$string['model_amazon.nova-micro-v1:0'] = 'Amazon Nova Micro';
$string['model_amazon.nova-pro-v1:0'] = 'Amazon Nova Pro';
$string['model_amazon.titan-image-generator-v2:0'] = 'Amazon Titan Image Generator V2';
$string['model_anthropic.claude-3-5-sonnet-20240620-v1:0'] = 'Claude 3.5 Sonnet V1';
$string['model_anthropic.claude-3-5-sonnet-20241022-v2:0'] = 'Claude 3.5 Sonnet V2';
$string['model_anthropic.claude-3-7-sonnet-20250219-v1:0'] = 'Claude 3.7 Sonnet V1';
$string['model_anthropic.claude-3-haiku-20240307-v1:0'] = 'Claude 3 Haiku';
$string['model_anthropic.claude-haiku-4-5-20251001-v1:0'] = 'Claude 4.5 Haiku';
$string['model_anthropic.claude-sonnet-4-20250514-v1:0'] = 'Claude 4.0 Sonnet V1';
$string['model_anthropic.claude-sonnet-4-5-20250929-v1:0'] = 'Claude 4.5 Sonnet V1';
$string['model_meta.llama3-1-405b-instruct-v1:0'] = 'Meta Llama 3.1 405B Instruct';
$string['model_meta.llama3-1-70b-instruct-v1:0'] = 'Meta Llama 3.1 70B Instruct';
$string['model_meta.llama3-1-8b-instruct-v1:0'] = 'Meta Llama 3.1 8B Instruct';
$string['model_meta.llama3-2-11b-instruct-v1:0'] = 'Meta Llama 3.2 11B Instruct';
$string['model_meta.llama3-2-1b-instruct-v1:0'] = 'Meta Llama 3.2 1B Instruct';
$string['model_meta.llama3-2-3b-instruct-v1:0'] = 'Meta Llama 3.2 3B Instruct';
$string['model_meta.llama3-2-90b-instruct-v1:0'] = 'Meta Llama 3.2 90B Instruct';
$string['model_meta.llama3-3-70b-instruct-v1:0'] = 'Meta Llama 3.3 70B Instruct';
$string['model_meta.llama3-70b-instruct-v1:0'] = 'Meta Llama 3 70B Instruct';
$string['model_meta.llama3-8b-instruct-v1:0'] = 'Meta Llama 3 8B Instruct';
$string['model_mistral.mistral-7b-instruct-v0:2'] = 'Mistral 7B Instruct';
$string['model_mistral.mistral-large-2402-v1:0'] = 'Mistral Large Instruct';
$string['model_mistral.mistral-small-2402-v1:0'] = 'Mistral Small Instruct';
$string['model_mistral.mixtral-8x7b-instruct-v0:1'] = 'Mixtral 8X7B Instruct';
$string['model_stability.sd3-5-large-v1:0'] = 'Stability AI Stable Diffusion 3.5 Large';
$string['model_stability.stable-image-core-v1:1'] = 'Stability AI Stable Image Core 1.1';
$string['model_stability.stable-image-ultra-v1:1'] = 'Stability AI Stable Image Ultra 1.1';
$string['none'] = 'Tidak Ada';
$string['pluginname'] = 'Penyedia AWS Bedrock';
$string['privacy:metadata'] = 'Pengaya penyedia AWS Bedrock tidak menyimpan data pribadi apa pun.';
$string['privacy:metadata:aiprovider_awsbedrock:externalpurpose'] = 'Informasi ini dikirimkan ke Amazon Web Services (AWS) agar mendapat respons yang dihasilkan. Pengaturan akun AWS Anda berubah bagaimana AWS menyimpan dan mempertahankan data ini. Tidak ada data pengguna secara eksplisit dikirimkan ke AWS atau disimpan di LMS Moodle oleh pengaya ini.';
$string['privacy:metadata:aiprovider_awsbedrock:model'] = 'Model yang digunakan untuk menghasilkan respons.';
$string['privacy:metadata:aiprovider_awsbedrock:numberimages'] = 'Saat menghasilkan gambar jumlah gambar yang digunakan dalam respons.';
$string['privacy:metadata:aiprovider_awsbedrock:prompttext'] = 'Pengguna memasukkan perintah teks yang digunakan untuk menghasilkan respons.';
$string['privacy:metadata:aiprovider_awsbedrock:responseformat'] = 'Format respons saat menghasilkan gambar.';
$string['settings'] = 'Pengaturan';
$string['settings_cfg_scale'] = 'Skala Classifier-Free Guidance (CFG)';
$string['settings_cfg_scale_help'] = 'Menentukan seberapa kuat gambar yang dihasilkan harus mengikuti perintah. Gunakan nilai yang lebih rendah untuk memperkenalkan lebih banyak keacakan dalam proses penghasilan. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_cross_region_inference'] = 'Inferensi lintas wilayah';
$string['settings_cross_region_inference_help'] = 'ID profil inferensi untuk model ini. Bawaan: {$a->default}';
$string['settings_frequency_penalty'] = 'Penalti frekuensi';
$string['settings_frequency_penalty_help'] = 'Penalti frekuensi menyesuaikan seberapa kali kata diulang. Lebih tinggi penalti, kurang berulang dalam teks dihasilkan. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_help'] = 'Sesuaikan pengaturan di bawah untuk menyesuaikan bagaimana permintaan dikirimkan ke Amazon Bedrock.';
$string['settings_max_tokens'] = 'Token maks';
$string['settings_max_tokens_help'] = 'Jumlah token maksimum digunakan untuk menghasilkan konten. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_negative_prompt_img'] = 'Perintah negatif';
$string['settings_negative_prompt_img_help'] = 'Menentukan kata kunci yang menggambarkan elemen yang harus dikecualikan dari gambar yang dihasilkan. Masukkan kata atau frasa pendek yang dipisahkan dengan koma. Panjang maksimum: 10.000 karakter';
$string['settings_presence_penalty'] = 'Penalti presensi';
$string['settings_presence_penalty_help'] = 'Kurangi frekuensi kata yang berulang dalam satu pesan dengan meningkatkan angka ini. Berbeda dengan penalti frekuensi, penalti presensi tetap sama terlepas dari berapa kali kata tersebut muncul. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_schema_version'] = 'Versi skema';
$string['settings_schema_version_help'] = 'Versi skema yang akan digunakan untuk permintaan. Bawaan: {$a->default}.';
$string['settings_seed'] = 'Seed';
$string['settings_seed_help'] = 'Memastikan hasil konsisten saat menggunakan benih dan parameter sama. Saat hasil secara umum dapat berulang, konsistensi total tidak 100% terjamin. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_seed_img'] = 'Seed';
$string['settings_seed_img_help'] = 'Menentukan pengaturan noise awal untuk proses penghasilan. Mengubah nilai seed sambil mempertahankan semua parameter lainnya tetap sama akan menghasilkan gambar baru yang sepenuhnya berbeda namun tetap sesuai dengan perintah, dimensi, dan pengaturan lainnya. Umumnya, orang mencoba berbagai nilai seed untuk menemukan gambar yang sempurna. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_stop_sequences'] = 'Sekuens henti';
$string['settings_stop_sequences_help'] = 'Tentukan sekuens karakter untuk mengindikasikan di mana model harus berhenti.';
$string['settings_temperature'] = 'Suhu';
$string['settings_temperature_help'] = 'Gunakan nilai yang lebih rendah untuk mengurangi tingkat acak dalam respons. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_top_k'] = 'Top K';
$string['settings_top_k_help'] = 'Hanya ambil sampel dari K opsi teratas untuk setiap token selanjutnya. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
$string['settings_top_p'] = 'Top P';
$string['settings_top_p_help'] = 'Gunakan nilai yang lebih rendah untuk mengabaikan opsi yang kurang mungkin dan mengurangi keragaman respons. Min: {$a->min}, Maks: {$a->max}, Bawaan: {$a->default}.';
