<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'choice', language 'id', version '5.2'.
 *
 * @package     choice
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addmorechoices'] = 'Tambahkan lebih banyak pilihan';
$string['allowmultiple'] = 'Izinkan lebih dari satu pilihan untuk dipilih';
$string['allowupdate'] = 'Izinkan pemilihan untuk diperbarui';
$string['answered'] = 'Dijawab';
$string['atleastoneoption'] = 'Anda harus memberikan setidaknya satu kemungkinan jawaban.';
$string['calendarend'] = '{$a} akan berakhir';
$string['calendarstart'] = '{$a} dibuka';
$string['cannotsubmit'] = 'Maaf, ada masalah saat mengirimkan pemilihan Anda. Silakan coba lagi.';
$string['choice'] = 'Pemilihan';
$string['choice:addinstance'] = 'Tambahkan pemilihan baru';
$string['choice:choose'] = 'Rekam pemilihan';
$string['choice:deleteresponses'] = 'Edit dan hapus tanggapan';
$string['choice:downloadresponses'] = 'Unduh tanggapan';
$string['choice:readresponses'] = 'Lihat tanggapan';
$string['choice:view'] = 'Lihat aktivitas pemilihan';
$string['choiceclose'] = 'Izinkan menanggapi sampai';
$string['choicefull'] = 'Satu atau lebih opsi yang Anda pilih telah diisi. Jawaban Anda belum disimpan. Harap tentukan pilihan lain.';
$string['choicename'] = 'Nama Pemilihan';
$string['choiceopen'] = 'Izinkan tanggapan dari';
$string['choiceoptions'] = 'Opsi Pemilihan';
$string['choiceoptions_help'] = 'Di sinilah Anda menentukan opsi yang harus dipilih peserta. Anda dapat mengisi nomor ini. Jika Anda membiarkan beberapa opsi kosong, opsi tersebut tidak akan ditampilkan. Jika Anda membutuhkan lebih dari 8 opsi, klik tombol "Tambahkan 3 bidang ke formulir".';
$string['choicesaved'] = 'Pilihan Anda telah tersimpan';
$string['choicetext'] = 'Teks Pemilihan';
$string['chooseaction'] = 'Pilih aksi ...';
$string['chooseoption'] = 'Pilih: {$a}';
$string['closebeforeopen'] = 'Anda telah menentukan tanggal tutup sebelum tanggal buka.';
$string['completiondetail:submit'] = 'Buat pilihan';
$string['completionsubmit'] = 'Membuat pilihan';
$string['description'] = 'Deskripsi';
$string['deselectalloption'] = 'Batalkan pilihan semua "{$a}"';
$string['displayhorizontal'] = 'Tampilan horisontal';
$string['displaymode'] = 'Mode tampilan untuk opsi';
$string['displayvertical'] = 'Tampilan vertikal';
$string['duedate'] = 'Tanggal jatuh tempo';
$string['eventanswercreated'] = 'Menambahkan pilihan jawaban';
$string['eventanswerdeleted'] = 'Menghapus pilihan jawaban';
$string['eventanswersubmitted'] = 'Membuat Pemilihan';
$string['eventanswerupdated'] = 'Perbarui Pemilihan';
$string['eventreportdownloaded'] = 'Mengunduh laporan Pemilihan';
$string['eventreportviewed'] = 'Melihat laporan Pemilihan';
$string['expired'] = 'Aktivitas ini ditutup pada: {$a}.';
$string['full'] = '(Penuh)';
$string['havetologin'] = 'Anda harus masuk sebelum Anda dapat mengirimkan pilihan Anda';
$string['includeinactive'] = 'Sertakan jawaban dari pengguna tidak aktif/ditangguhkan';
$string['indicator:cognitivedepth'] = 'Pemilihan kognitif';
$string['indicator:cognitivedepth_help'] = 'Indikator ini didasarkan pada kedalaman kognitif yang dicapai siswa dalam suatu aktivitas Pemilihan.';
$string['indicator:cognitivedepthdef'] = 'Pemilihan kognitif';
$string['indicator:cognitivedepthdef_help'] = 'Peserta telah mencapai persentase keterlibatan kognitif yang ditawarkan oleh aktivitas Pemilihan selama interval analisis ini (Tingkat = Tidak ada tampilan, Lihat, Kirim, Lihat umpan balik)';
$string['indicator:cognitivedepthdef_link'] = 'Learning_analytics_indicators#Cognitive_depth';
$string['indicator:socialbreadth'] = 'Pemilihan sosial';
$string['indicator:socialbreadth_help'] = 'Indikator ini didasarkan pada keluasan sosial yang dicapai siswa dalam suatu aktivitas Pemilihan.';
$string['indicator:socialbreadthdef'] = 'Pemilihan sosial';
$string['indicator:socialbreadthdef_help'] = 'Peserta telah mencapai persentase keterlibatan sosial yang ditawarkan oleh aktivitas Pemilihan selama interval analisis ini (Tingkat = Tidak ada partisipasi, Peserta sendiri, Peserta dengan orang lain)';
$string['indicator:socialbreadthdef_link'] = 'Learning_analytics_indicators#Social_breadth';
$string['limit'] = 'Batas';
$string['limita'] = 'Batas: {$a}';
$string['limitanswers'] = 'Batasi jumlah jawaban yang diperbolehkan';
$string['limitanswers_help'] = 'Opsi ini memungkinkan Anda untuk membatasi jumlah peserta yang dapat memilih setiap opsi pilihan. Ketika batas tercapai maka tidak ada orang lain yang dapat memilih opsi itu.

Harap dicatat bahwa jika Anda menggunakan aktivitas ini dalam mode grup, maka batasnya adalah per grup. Misalnya, jika batas ditetapkan ke 5, maka 5 anggota dari setiap grup dapat memilih opsi tersebut. Jika ada 3 kelompok, ini berarti maksimal 5 x 3 = 15 peserta dapat memilih opsi tersebut.

Jika batas dinonaktifkan maka sejumlah peserta dapat memilih masing-masing opsi.';
$string['limitno'] = 'Batas {no}';
$string['modulename'] = 'Pemilihan';
$string['modulename_help'] = '###### Fitur utama
* Batasi jumlah orang yang dapat memilih setiap opsi
* Publikasikan hasil atau sembunyikan
* Buat hasil anonim atau tampilkan nama siswa

###### Cara menggunakannya
* Biarkan siswa memilih kelompok seminar atau tim proyek
* Minta siswa untuk memilih tanggal atau topik yang disukai
* Periksa pemahaman suatu konsep dengan pertanyaan anonim singkat';
$string['modulename_link'] = 'mod/choice/view';
$string['modulename_summary'] = 'Jalankan pendapat satu pertanyaan dan biarkan siswa memilih dari daftar pilihan.';
$string['modulenameplural'] = 'Pemilihan';
$string['moveselectedusersto'] = 'Pindah pengguna terpilih ke ...';
$string['multiplenotallowederror'] = 'Tidak diizinkan memilih banyak pada pilihan ini';
$string['mustchooseone'] = 'Anda harus memilih jawaban sebelum menyimpan. Tidak ada yang tersimpan.';
$string['noguestchoose'] = 'Maaf, tamu tidak diperbolehkan membuat pilihan.';
$string['noresultsviewable'] = 'Hasilnya saat ini tidak dapat dilihat.';
$string['notanswered'] = 'Belum dijawab';
$string['notenrolledchoose'] = 'Maaf, hanya pengguna terdaftar yang diizinkan untuk membuat pilihan.';
$string['notopenyet'] = 'Aktivitas ini tidak tersedia hingga {$a}.';
$string['numberofuser'] = 'Jumlah tanggapan';
$string['numberofuserinpercentage'] = 'Persentasi presentasi';
$string['openafterclose'] = 'Anda telah menentukan tanggal buka setelah tanggal tutup';
$string['option'] = 'Opsi';
$string['optionno'] = 'Opsi {no}';
$string['options'] = 'Opsi';
$string['page-mod-choice-x'] = 'Setiap halaman modul pemilihan';
$string['pluginadministration'] = 'Administrasi pemilihan';
$string['pluginname'] = 'Pemilihan';
$string['previewing'] = 'Ini hanyalah pratinjau dari opsi yang tersedia untuk aktivitas ini. Anda akan dapat membuat pilihan saat terbuka.';
$string['previewonly'] = 'Ini hanyalah pratinjau dari opsi yang tersedia untuk aktivitas ini. Anda tidak akan bisa mengirimkan pilihan Anda sampai {$a}.';
$string['privacy'] = 'Privasi hasil';
$string['privacy:metadata:choice_answers'] = 'Informasi tentang jawaban yang dipilih pengguna untuk aktivitas pemilihan yang diberikan';
$string['privacy:metadata:choice_answers:choiceid'] = 'ID aktivitas pemilihan';
$string['privacy:metadata:choice_answers:optionid'] = 'ID opsi yang dipilih pengguna.';
$string['privacy:metadata:choice_answers:timemodified'] = 'Stempel waktu yang menunjukkan kapan pemilihan diubah oleh pengguna';
$string['privacy:metadata:choice_answers:userid'] = 'ID pengguna yang menjawab aktivitas pilihan ini';
$string['publish'] = 'Publikasikan hasil';
$string['publishafteranswer'] = 'Tunjukkan hasil kepada siswa setelah mereka menjawab';
$string['publishafterclose'] = 'Tampilkan hasil kepada siswa hanya setelah Pemilihan ditutup';
$string['publishalways'] = 'Selalu tunjukkan hasil kepada siswa';
$string['publishanonymous'] = 'Publikasikan hasil anonim, jangan tampilkan nama siswa';
$string['publishinfoanonafter'] = 'Hasil anonim akan dipublikasikan setelah Anda menjawab.';
$string['publishinfoanonclose'] = 'Hasil anonim akan dipublikasikan setelah aktivitas ditutup.';
$string['publishinfofullafter'] = 'Hasil lengkap, menunjukkan pilihan semua orang, akan dipublikasikan setelah Anda menjawab.';
$string['publishinfofullclose'] = 'Hasil lengkap, menunjukkan pilihan semua orang, akan dipublikasikan setelah aktivitas ditutup.';
$string['publishinfonever'] = 'Hasil aktivitas ini tidak akan dipublikasikan setelah Anda menjawab.';
$string['publishnames'] = 'Publikasikan hasil lengkap, tunjukkan nama dan pilihannya';
$string['publishnot'] = 'Jangan mempublikasikan hasil kepada siswa';
$string['removemychoice'] = 'Hapus pilihan saya';
$string['removeresponses'] = 'Semua tanggapan';
$string['responded'] = 'Menanggapi';
$string['responses'] = 'Tanggapan';
$string['responsesa'] = 'Tanggapan: {$a}';
$string['responsesresultgraphheader'] = 'Tampilan grafik';
$string['responsesto'] = 'Tanggapan untuk {$a}';
$string['results'] = 'Hasil';
$string['savemychoice'] = 'Simpan pilihan saya';
$string['search:activity'] = 'Pemilihan';
$string['selectalloption'] = 'Pilih semua "{$a}"';
$string['showavailable'] = 'Tampilkan ruang yang tersedia';
$string['showavailable_help'] = 'Tunjukkan kepada peserta batas untuk setiap opsi dan jumlah tanggapan sejauh ini.';
$string['showpreview'] = 'Tampilkan pratinjau';
$string['showpreview_help'] = 'Izinkan siswa untuk melihat pratinjau opsi yang tersedia sebelum pilihan dibuka untuk diserahkan.';
$string['showunanswered'] = 'Tampilkan kolom untuk yang belum terjawab';
$string['spaceleft'] = 'ruang yang tersedia';
$string['spacesleft'] = 'ruang yang tersedia';
$string['studentwhoresponded'] = 'Siswa yang menanggapi';
$string['taken'] = 'Dilakukan';
$string['totalresponses'] = 'Total tanggapan';
$string['userchoosethisoption'] = 'Pengguna yang memilih opsi ini';
$string['viewallresponses'] = 'Lihat {$a} tanggapan';
$string['viewchoices'] = 'Lihat pilihan';
$string['withselected'] = 'Dengan yang terpilih';
$string['yourselection'] = 'Pilihan Anda';
