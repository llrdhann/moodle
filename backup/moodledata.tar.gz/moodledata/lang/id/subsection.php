<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'subsection', language 'id', version '5.2'.
 *
 * @package     subsection
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cleandescriptionsdetail'] = 'Halaman dan deskripsi subbagian tidak lagi didukung di Moodle 5.2.
<p>Situs ini memiliki <strong>{$a->count} deskripsi subbagian</strong> yang tidak lagi terlihat oleh pengguna.</p>
<p>Anda dapat memilih untuk:
<ul>
   <li><strong>Memindahkan deskripsi ini ke area Teks dan Media</strong>.<br/> Area Teks dan media akan ditampilkan di bagian atas setiap subbagian.<br/>{$a->migratelink}<br/><br/>
   </li>
   <li><strong>Menghapus deskripsi ini secara permanen</strong>.<br/> Ini akan menghapus deskripsi sepenuhnya dari basis data.<br/>{$a->deletelink}
   </li>
</ul>
</p>';
$string['deleteconfirmbutton'] = 'Hapus semua deskripsi';
$string['deleteconfirmtext'] = 'Ini akan menghapus {$a} deskripsi subbagian secara permanen dari basis data.<br/><br/>Anda tidak dapat membatalkan tindakan ini. Apakah Anda yakin ingin menghapus semua deskripsi?';
$string['deleteconfirmtitle'] = 'Hapus semua deskripsi subbagian';
$string['deletelinktext'] = 'Hapus deskripsi';
$string['descriptionsdeletedpending'] = 'Deskripsi subbagian yang menunggu untuk dihapus: <strong>{$a}</strong>';
$string['descriptionsdeletedsuccess'] = '<strong>Tugas penghapusan untuk semua deskripsi subbagian telah dibuat</strong>. Tugas ini akan berjalan di latar belakang dan mungkin membutuhkan beberapa menit.';
$string['descriptionsmigratedpending'] = 'Deskripsi subbagian yang menunggu untuk dimigrasikan: <strong>{$a}</strong>';
$string['descriptionsmigratedsuccess'] = '<strong>Tugas migrasi untuk semua deskripsi subbagian telah dibuat.</strong> Tugas ini akan berjalan di latar belakang dan mungkin membutuhkan beberapa menit.';
$string['invalidaction'] = 'Tindakan yang ditentukan tidak valid.';
$string['migrateconfirmbutton'] = 'Migrasikan semua deskripsi';
$string['migrateconfirmtext'] = 'Ini akan memigrasikan {$a} deskripsi subbagian ke area Teks dan Media.<br/><br/>Anda tidak dapat membatalkan ini. Apakah Anda yakin ingin memigrasikan semua deskripsi?';
$string['migrateconfirmtitle'] = 'Migrasikan semua deskripsi subbagian?';
$string['migratelinktext'] = 'Migrasikan deskripsi';
$string['modulename'] = 'Subtopik';
$string['modulenameplural'] = 'Subtopik';
$string['pluginadministration'] = 'Administrasi Subtopik';
$string['pluginname'] = 'Subtopik';
$string['privacy:metadata'] = 'Subtopik tidak menyimpan data pribadi apa pun';
$string['quickcreatename'] = 'Subtopik baru';
$string['subsection:addinstance'] = 'Tambahkan Subtopik';
$string['subsection:view'] = 'Lihat Subtopik';
$string['subsectionname'] = 'Nama';
