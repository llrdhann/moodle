<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'tool_mobile', language 'id', version '5.2'.
 *
 * @package     tool_mobile
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activitiesoverview'] = 'Ikhtisar aktivitas';
$string['adodbdebugwarning'] = 'Awakutu ADOdb diaktifkan. Ini harus dinonaktifkan dalam autentikasi basis data eksternal atau setelan pengaya pendaftaran basis data eksternal.';
$string['androidappid'] = 'pengenal unik aplikasi Android';
$string['androidappid_desc'] = 'Setelan ini dapat dibiarkan sebagai bawaan kecuali Anda memiliki aplikasi Android kustom.';
$string['apppolicy'] = 'URL kebijakan aplikasi';
$string['apppolicy_help'] = 'URL kebijakan untuk pengguna aplikasi yang tercantum di halaman Tentang di aplikasi. Jika bidang dibiarkan kosong, URL kebijakan situs akan digunakan sebagai gantinya.';
$string['apprequired'] = 'Fungsionalitas ini hanya tersedia saat diakses melalui aplikasi seluler atau desktop Moodle.';
$string['autologinkeygenerationlockout'] = 'Pembuatan kunci masuk otomatis diblokir. Anda harus menunggu {$a} menit di antara permintaan.';
$string['autologinmintimebetweenreq'] = 'Waktu minimum antara permintaan masuk otomatis.';
$string['autologinmintimebetweenreq_desc'] = 'Setelan ini menentukan waktu minimum antara permintaan masuk otomatis dari aplikasi. Anda harus menyetel setelan ini ke nilai rendah jika pengguna aplikasi seluler sering diminta memasukkan kredensial mereka saat memvisualisasikan konten yang disematkan dari situs.';
$string['autologinnotallowedtoadmins'] = 'Log masuk otomatis tidak diizinkan untuk admin situs.';
$string['autologout'] = 'Terapkan logout otomatis untuk pengguna Anda';
$string['autologout_desc'] = 'Untuk alasan keamanan, Anda dapat memberlakukan logout otomatis untuk pengguna Anda saat mereka keluar atau menutup aplikasi, atau beralih ke latar belakang. Pengguna harus masuk lagi ketika mereka kembali ke aplikasi.';
$string['autologoutcustom'] = 'Waktu kustom setelah pengguna keluar atau menutup aplikasi';
$string['autologoutinmediate'] = 'Segera setelah pengguna keluar atau menutup aplikasi';
$string['autologouttime'] = 'Penghitung waktu keluar otomatis';
$string['billedannually'] = 'Ditagih tahunan';
$string['branding'] = 'Merek';
$string['cachedef_plugininfo'] = 'Ini menyimpan daftar pengaya dengan tambahan seluler';
$string['cachedef_subscriptioninfo'] = 'Ini menyimpan informasi langganan aplikasi Moodle.';
$string['clickheretolaunchtheapp'] = 'Klik di sini jika aplikasi tidak terbuka secara otomatis.';
$string['configmobilecssurl'] = 'Berkas CSS untuk menyesuaikan antarmuka aplikasi seluler Anda.';
$string['currentusage'] = 'Penggunaan saat ini';
$string['customisation'] = 'Penyesuaian';
$string['customlangstrings'] = 'String bahasa kustom';
$string['customlangstrings_desc'] = 'Kata dan frasa yang ditampilkan di aplikasi dapat disesuaikan di sini. Masukkan setiap string bahasa kustom pada baris baru dengan format: pengidentifikasi string, string bahasa kustom, dan kode bahasa, dipisahkan oleh karakter pipa. Misalnya:
<pre>
core.user.student|Learner|en
core.user.student|Aprendiz|es
</pre>
Untuk daftar lengkap pengidentifikasi string, lihat dokumentasi.';
$string['custommenuitems'] = 'Untuk daftar lengkap pengidentifikasi string, lihat dokumentasi.';
$string['custommenuitems_desc'] = 'Item tambahan dapat ditambahkan ke menu utama aplikasi dengan menentukannya di sini. Masukkan setiap item menu kustom pada baris baru dengan format: teks item, URL tautan, metode pembukaan tautan, dan kode bahasa (opsional, untuk menampilkan item kepada pengguna bahasa tertentu saja), dipisahkan dengan karakter pipa.

Metode pembukaan tautan adalah: aplikasi (untuk menautkan ke aktivitas yang didukung oleh aplikasi), peramban dalam aplikasi (untuk membuka tautan di peramban tanpa meninggalkan aplikasi), browser (untuk membuka tautan di peramban bawaan perangkat di luar aplikasi) dan disematkan (untuk menampilkan tautan dalam iframe di halaman baru di aplikasi).

Saat item tidak memiliki terjemahan untuk bahasa tertentu, item tersebut akan menggunakan bahasa lain sebagai pengganti kecuali "_only" ditambahkan ke kode bahasa.

Sebagai contoh:
<pra>
Bantuan aplikasi|https://someurl.xyz/help|inappbrowser
Nilai saya|https://someurl.xyz/local/mygrades/index.php|embedded|en
Mis calificaciones|https://someurl.xyz/local/mygrades/index.php|embedded|es
Anda hanya akan melihat ini dalam bahasa Inggris|https://someurl.xyz/english|browser|en_only
</pre>';
$string['customusermenuitems'] = 'Item menu pengguna kustom';
$string['customusermenuitems_desc'] = 'Item tambahan dapat ditambahkan ke menu pengguna aplikasi dengan menentukannya di sini. Masukkan setiap item menu pengguna kustom pada baris baru dengan format: teks item, URL tautan, metode pembukaan tautan, dan kode bahasa (opsional, untuk menampilkan item hanya kepada pengguna dengan bahasa yang ditentukan), dipisahkan oleh karakter pipa.

Metode pembukaan tautan adalah: app (untuk menautkan ke aktivitas yang didukung oleh aplikasi), inappbrowser (untuk membuka tautan di browser tanpa meninggalkan aplikasi), browser (untuk membuka tautan di browser default perangkat di luar aplikasi), dan embedded (untuk menampilkan tautan dalam iframe di halaman baru di aplikasi).

Jika item tidak memiliki terjemahan untuk bahasa tertentu, item tersebut akan menggunakan bahasa lain sebagai cadangan kecuali jika "_only" ditambahkan ke kode bahasa.

Misalnya:
<pre>
Bantuan aplikasi|https://someurl.xyz/help|inappbrowser
Nilai saya|https://someurl.xyz/local/mygrades/index.php|embedded|en
Nilai saya|https://someurl.xyz/local/mygrades/index.php|embedded|es
Anda hanya akan melihat ini dalam bahasa Inggris|https://someurl.xyz/english|browser|en_only
</pre>';
$string['darkmode'] = 'Mode gelap';
$string['devicelimitnotrack'] = 'Batas per perangkat (tidak ada pelacakan penggunaan)';
$string['disabledfeatures'] = 'Fitur yang dinonaktifkan';
$string['disabledfeatures_desc'] = 'Pilih di sini fitur yang ingin Anda nonaktifkan di aplikasi Seluler untuk situs Anda. Harap dicatat bahwa beberapa fitur yang tercantum di sini mungkin sudah dinonaktifkan melalui setelan situs lain. Anda harus keluar dan masuk lagi di aplikasi untuk melihat perubahannya.';
$string['displayerrorswarning'] = 'Tampilan pesan awakutu (debugdisplay) diaktifkan. Ini harus dinonaktifkan.';
$string['downloadcourse'] = 'Unduh kursus';
$string['downloadcourses'] = 'Unduh kursus';
$string['enablesmartappbanners'] = 'Aktifkan Spanduk Aplikasi';
$string['enablesmartappbanners_desc'] = 'Jika diaktifkan, spanduk yang mempromosikan aplikasi seluler akan ditampilkan saat mengakses situs menggunakan peramban seluler.';
$string['enhanced'] = 'Premium';
$string['feature'] = 'Fitur';
$string['featurecomparison'] = 'Perbandingan fitur';
$string['filetypeexclusionlist'] = 'Daftar pengecualian jenis berkas';
$string['filetypeexclusionlist_desc'] = 'Pilih semua jenis berkas yang tidak untuk digunakan pada perangkat seluler. Berkas tersebut akan terdaftar dalam kursus, kemudian jika pengguna mencoba untuk membukanya, peringatan akan ditampilkan yang memberitahukan bahwa jenis berkas tidak dimaksudkan untuk digunakan pada perangkat seluler. Pengguna kemudian dapat membatalkan atau mengabaikan peringatan dan tetap membuka berkas.';
$string['filetypeexclusionlistplaceholder'] = 'Daftar pengecualian jenis berkas seluler';
$string['forcedurlscheme'] = 'Jika Anda ingin hanya mengizinkan aplikasi bermerek kustom Anda untuk dibuka melalui jendela peramban, tentukan skema URL-nya di sini. Jika Anda hanya ingin mengizinkan aplikasi resmi, setel nilai bawaan. Biarkan kolom kosong jika Anda ingin mengizinkan aplikasi apa pun.';
$string['forcedurlscheme_key'] = 'Skema URL';
$string['forcelogout'] = 'Paksa keluar';
$string['forcelogout_desc'] = 'Jika diaktifkan, pengguna akan selalu keluar sepenuhnya bahkan saat berpindah akun. Mereka kemudian harus memasukkan kembali kata sandi mereka saat berikutnya mereka ingin mengakses situs.';
$string['fullaccessfeatures'] = 'Anda memiliki akses penuh ke {$a} fitur';
$string['getmoodleonyourmobile'] = 'Dapatkan aplikasi seluler';
$string['h5poffline'] = 'Lihat konten H5P secara luring';
$string['httpsrequired'] = 'Wajib HTTPS';
$string['insecurealgorithmwarning'] = 'Tampaknya sertifikat HTTPS menggunakan algoritme yang tidak aman untuk penandatanganan (SHA-1). Coba perbarui sertifikat.';
$string['invalidcertificatechainwarning'] = 'Tampaknya rantai sertifikat tidak valid. Sertifikat ini mungkin berfungsi untuk peramban tetapi tidak untuk aplikasi seluler.';
$string['invalidcertificateexpiredatewarning'] = 'Tampaknya sertifikat HTTPS untuk situs tersebut telah kedaluwarsa.';
$string['invalidcertificatestartdatewarning'] = 'Tampaknya sertifikat HTTPS untuk situs tersebut belum valid (dengan tanggal mulai di masa mendatang).';
$string['invalidprivatetoken'] = 'Token pribadi tidak valid. Token tidak boleh kosong atau diteruskan melalui parameter GET.';
$string['invaliduserquotawarning'] = 'Kuota pengguna (userquota) disetel ke nomor yang tidak valid. Ini harus diatur ke nomor yang valid (nilai integer) dalam setelan keamanan Situs.';
$string['iosappid'] = 'Pengenal unik aplikasi iOS';
$string['iosappid_desc'] = 'Setelan ini dapat dibiarkan sebagai bawaan kecuali Anda memiliki aplikasi iOS kustom.';
$string['launchviasiteinbrowser'] = 'Luncurkan melalui situs di peramban sistem';
$string['learnmore'] = 'Pelajari lebih lanjut';
$string['limiteddisabledfeature'] = 'Paket <strong>{$a->plan</strong> Anda mengizinkan {$a->limit} {$a->feature}. <a href="{$a->url}">Lihat detail paket</a>.';
$string['limiteddisabledfeature_related'] = 'Paket <strong>{$a->plan</strong> Anda memungkinkan {$a->limit} total item di <strong>{$a->feature1}</strong> dan <strong>{$a->feature2}</strong>. <a href="{$a->url}">Lihat detail paket</a>.';
$string['limitedfeatures'] = 'Fitur terbatas';
$string['loginintheapp'] = 'Via aplikasi';
$string['logininthebrowser'] = 'Melalui jendela peramban (untuk pengaya SSO)';
$string['loginintheembeddedbrowser'] = 'Melalui peramban tersemat (untuk pengaya SSO)';
$string['logoutconfirmation'] = 'Anda yakin ingin keluar dari aplikasi seluler di perangkat seluler Anda? Dengan keluar, Anda harus memasukkan kembali nama pengguna dan kata sandi Anda di aplikasi seluler di semua perangkat tempat Anda menginstal aplikasi tersebut.';
$string['lookingforcsscustomisation'] = 'Mencari penyesuaian CSS?';
$string['lookingforcustomisationfeatures'] = 'Mencari fitur penyesuaian?';
$string['lookingforqrcodelogin'] = 'Mencari kode masuk QR?';
$string['mainmenu'] = 'Menu utama';
$string['manage'] = 'Kelola';
$string['managefiletypes'] = 'Kelola jenis berkas';
$string['minimumversion'] = 'Jika versi aplikasi ditentukan (3.8.0 atau lebih tinggi), pengguna mana pun yang menggunakan versi aplikasi yang lebih lama akan diminta untuk meningkatkan aplikasi mereka sebelum diizinkan mengakses situs.';
$string['minimumversion_key'] = 'Diperlukan versi aplikasi minimum';
$string['mobileapp'] = 'Aplikasi seluler';
$string['mobileappearance'] = 'Tampilan seluler';
$string['mobileappenabled'] = 'Situs ini mengaktifkan akses aplikasi seluler.<br /><a href="{$a}">Unduh aplikasi seluler</a>.';
$string['mobileappsubscription'] = 'Berlangganan aplikasi Moodle';
$string['mobileauthentication'] = 'Autentikasi seluler';
$string['mobilecssurl'] = 'CSS';
$string['mobilefeatures'] = 'Fitur seluler';
$string['mobilenotificationsdisabledwarning'] = 'Notifikasi seluler tidak diaktifkan. Mereka harus diaktifkan di setelan notifikasi.';
$string['mobilesettings'] = 'Setelan seluler';
$string['moodleappsportalfeatureswarning'] = 'Harap dicatat bahwa beberapa fitur mungkin dibatasi tergantung pada langganan aplikasi Moodle Anda. Untuk detailnya, kunjungi <a href="{$a}" target="_blank">Portal Aplikasi Moodle</a>.';
$string['movedcsstopremiumfeatures'] = 'CSS untuk penyesuaian aplikasi seluler telah dipindahkan ke bagian <a href="{$a->url}">{$a->urlname}</a>.';
$string['moveddisabledtopremiumfeatures'] = 'Fitur seperti fitur ternonaktif, item menu kustom, dan penyesuaian bahasa telah dipindahkan ke bagian <a href="{$a->url}">{$a->urlname}</a>.';
$string['movedqrtopremiumfeatures'] = 'Akses kode QR telah dipindahkan ke bagian <a href="{$a->url}">{$a->urlname}</a>. Ini mencakup kode QR dasar (gratis) dan login kode QR otomatis ({$a->upgradename}).';
$string['new'] = '(Baru! ⭐️)';
$string['nosubsblocked'] = 'Server Moodle Anda mungkin memblokir koneksi keluar ke Portal Aplikasi Moodle.';
$string['nosubscouldntretrieve'] = 'Kami tidak dapat menerima rincian paket Anda';
$string['nosubsoerror'] = 'Tidak dapat terhubung ke Portal Aplikasi Moodle. Paket, batasan fitur, dan data penggunaan Anda untuk sementara tidak tersedia. Ini tidak memengaruhi langganan aktif Anda.';
$string['nosubstryagain'] = 'Coba lagi';
$string['nosubsviewplan'] = 'Lihat paket Anda pada Portal Aplikasi Moodle';
$string['nosubswhyhappen'] = 'Kenapa mungkin ini terjadi?';
$string['notifications'] = 'Pemberitahuan';
$string['notificationsactivedevices'] = 'Perangkat aktif';
$string['notificationscurrentactivedevices'] = 'Perangkat yang menerima notifikasi bulan ini';
$string['notificationsignorednotifications'] = 'Notifikasi tidak terkirim';
$string['notificationslimitreached'] = 'Batas perangkat bulanan telah tercapai. Beberapa pengguna tidak menerima pemberitahuan push. Tingkatkan paket Anda untuk memastikan semua pengguna menerima notifikasi seluler.';
$string['notificationsmissingwarning'] = 'Tidak dapat mengambil statistik pemberitahuan aplikasi Moodle. Pastikan notifikasi seluler diaktifkan di <a href="{$a}">Administrasi situs > Perpesanan > Seluler</a>.';
$string['notificationsnewdevices'] = 'Perangkat baru';
$string['notificationsseemore'] = 'Catatan: Statistik penggunaan aplikasi Moodle tidak dihitung secara langsung. Untuk mengakses statistik yang lebih detail, termasuk data dari bulan-bulan sebelumnya, harap masuk ke <a href="{$a}" target="_blank">Portal Aplikasi Moodle</a>.';
$string['notificationssentnotifications'] = 'Notifikasi terkirim';
$string['oauth2identityproviders'] = 'Penyedia identitas OAuth 2';
$string['offlineuse'] = 'Penggunaan luring';
$string['planbenefits'] = 'Manfaat paket {$a} Anda';
$string['plancontinues'] = 'Paket {$a} Anda berlanjut tanpa perubahan';
$string['plandetails'] = 'Langganan aplikasi Moodle Anda';
$string['planexpireson'] = 'Kedaluwarsa pada {$a}.';
$string['planfeatures'] = '{$a} fitur';
$string['planlastchecked'] = 'Status paket terakhir diperiksa pada {$a}.';
$string['planneverchecked'] = 'Status paket belum pernah diperiksa.';
$string['pluginname'] = 'Alat aplikasi Moodle';
$string['pluginnotenabledorconfigured'] = 'Pengaya tidak diaktifkan atau dikonfigurasi.';
$string['premiumfeatureonly'] = 'Hanya fitur premium';
$string['premiumfeatures'] = 'Fitur premium';
$string['privacy:metadata:core_userkey'] = 'Kunci pengguna digunakan untuk membuat kunci masuk otomatis untuk pengguna saat ini.';
$string['privacy:metadata:preference:tool_mobile_autologin_request_last'] = 'Tanggal permintaan kunci masuk otomatis terakhir. Di antara setiap permintaan diperlukan 6 menit.';
$string['qrcodedisabled'] = 'Akses melalui kode QR dinonaktifkan';
$string['qrcodeformobileappaccess'] = 'Kode QR untuk akses aplikasi seluler';
$string['qrcodeformobileapploginabout'] = 'Pindai kode QR dengan aplikasi seluler Anda dan Anda akan masuk secara otomatis. Kode QR akan kedaluwarsa dalam {$a}.';
$string['qrcodeformobileappurlabout'] = 'Pindai kode QR dengan aplikasi seluler Anda untuk mengisi URL situs di aplikasi Anda.';
$string['qrcodetype'] = 'Akses kode QR';
$string['qrcodetype_desc'] = 'Pengguna seluler dapat memindai kode QR untuk mengisi URL situs. Untuk situs aman (HTTPS), kode juga mengaktifkan masuk otomatis tanpa pengguna harus memasukkan nama pengguna dan kata sandi mereka.';
$string['qrcodetypelogin'] = 'Kode QR dengan login otomatis';
$string['qrcodetypeurl'] = 'Kode QR dengan URL situs (gratis)';
$string['qrkeyttl'] = 'Durasi kunci autentikasi QR';
$string['qrkeyttl_desc'] = 'Lama waktu validitas kode QR untuk autentikasi. Nilai kosong tidak diperbolehkan, dalam hal ini nilai bawaan untuk setelan akan digunakan.';
$string['qronlypremium'] = '{$a->feature} hanya tersedia dalam Premium. Tingkatkan untuk menggunakan kode QR dengan login otomatis. <a href="{$a->url}">Lihat detail paket</a>.';
$string['qrsameipcheck'] = 'Otentikasi QR, pemeriksaan IP yang sama';
$string['qrsameipcheck_desc'] = 'Apakah pengguna harus menggunakan jaringan yang sama untuk menghasilkan dan memindai kode QR untuk log masuk. Hanya nonaktifkan jika pengguna melaporkan masalah dengan log masuk QR.';
$string['qrsiteadminsnotallowed'] = 'Untuk alasan keamanan log masuk melalui kode QR tidak diperbolehkan untuk administrator situs atau jika Anda masuk sebagai pengguna lain.';
$string['readingthisemailgettheapp'] = 'Membaca ini di surel? <a href="{$a}">Unduh aplikasi seluler dan terima pemberitahuan di perangkat seluler Anda</a>.';
$string['refreshplanstatus'] = 'Muat ulang status paket';
$string['register'] = 'Daftar';
$string['remoteaddons'] = 'Pengaya jarak jauh';
$string['responsivemainmenuitems'] = 'Item menu responsif';
$string['scanqrcode'] = 'Pindai kode QR';
$string['scriptallowlist'] = 'Domain JavaScript yang diizinkan';
$string['scriptallowlist_desc'] = 'Masukkan domain yang diizinkan untuk memuat berkas JavaScript eksternal oleh aplikasi Moodle ketika terdeteksi dalam konten HTML yang dibuat pengguna.<br>
Setiap domain harus ditulis pada baris terpisah. Skrip yang sumbernya berasal dari salah satu domain yang tercantum akan diizinkan untuk dimuat. Skrip dari domain lain akan tetap diblokir.<br>
JavaScript inline selalu diblokir dan tidak diizinkan.';
$string['selfsignedoruntrustedcertificatewarning'] = 'Tampaknya sertifikat HTTPS ditandatangani sendiri atau tidak dipercaya. Aplikasi seluler hanya akan berfungsi dengan situs tepercaya. Silakan, gunakan alat pemeriksa SSL daring apa pun untuk mendiagnosis masalah lebih lanjut. Jika alat ini menunjukkan bahwa sertifikat Anda OK, Anda dapat mengabaikan peringatan ini.';
$string['setuplink'] = 'Halaman unduh aplikasi';
$string['setuplink_desc'] = 'URL halaman dengan opsi untuk mengunduh aplikasi seluler dari App Store dan Google Play. Tautan halaman unduhan aplikasi ditampilkan di footer halaman dan di profil pengguna. Biarkan kosong agar tidak menampilkan tautan.';
$string['showingcacheddata'] = 'Disinkron terakhir: {$a->since} hari yang lalu ({$a->date}).';
$string['showinglivedata'] = 'Lihat data langsung di <a href="{$a}" target="_blank">Portal Aplikasi Moodle</a>.';
$string['siteplugins'] = 'Pengaya situs';
$string['smartappbanners'] = 'Spanduk Aplikasi';
$string['subscription'] = 'Berlangganan';
$string['subscriptioncreated'] = 'Mulai tanggal';
$string['subscriptionerrorrequest'] = 'Galat tak terduga saat mencoba mengambil informasi langganan aplikasi Moodle Anda.';
$string['subscriptionexpiration'] = 'Tanggal kedaluwarsa';
$string['subscriptionfeaturenotapplied'] = 'Fitur ini dikonfigurasi di situs Anda tetapi tidak termasuk dalam paket aplikasi Moodle Anda. Dengan demikian, setelan tidak akan berpengaruh.';
$string['subscriptionfeatures'] = 'Fitur berlangganan';
$string['subscriptionlimitsurpassed'] = 'Batas berlangganan terlampaui';
$string['subscriptionregister'] = 'Untuk detail berbagai paket aplikasi, dan untuk mengakses statistik penggunaan aplikasi Moodle, silakan kunjungi <a href="{$a}" target="_blank">Portal Aplikasi Moodle</a>.';
$string['subscriptionsseemore'] = 'Catatan: Informasi yang ditampilkan tidak diperbarui secara real time. Anda mungkin perlu keluar dan masuk lagi untuk melihat pembaruan. Untuk informasi tentang meningkatkan paket aplikasi Anda, harap masuk ke <a href="{$a}" target="_blank">Portal Aplikasi Moodle</a>.';
$string['switchaccount'] = 'Beralih akun';
$string['taskrefreshsubscriptioncache'] = 'Muat ulang simpanan informasi langganan aplikasi Moodle';
$string['typeoflogin'] = 'Jenis login';
$string['typeoflogin_desc'] = 'Jika situs menggunakan metode autentikasi Masuk Tunggal (SSO), kemudian pilih melalui jendela peramban atau melalui peramban tersemat. Peramban tersemat menyediakan pengalaman pengguna lebih baik, meskipun itu tidak bekerja dengan semua pengaya SSO.';
$string['upgradeforunlimit'] = 'Tingkatkan ke {$a} untuk akses tanpa batas.';
$string['upgradeplanlimits'] = 'Beberapa fitur tersedia dengan batasan pada paket {$a}.';
$string['upgraderemovelimits'] = 'Tingkatkan ke {$a} dan hapus semua batasan.';
$string['upgradetosubscription'] = 'Tingkatkan ke {$a}';
$string['upgradeyourplan'] = '(Tingkatkan paket Anda! 🚀)';
$string['viewqrcode'] = 'Lihat kode QR';
