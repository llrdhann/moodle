<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'datafield_text', language 'id', version '5.2'.
 *
 * @package     datafield_text
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['fieldtypelabel'] = 'Teks pendek';
$string['pluginname'] = 'Teks pendek';
$string['privacy:metadata'] = 'Komponen ruas Teks Pendek tidak menyimpan data pribadi apa pun, komponen ini menggunakan tabel yang ditentukan dalam mod_data.';
$string['sample'] = 'Ini adalah teks singkat';
